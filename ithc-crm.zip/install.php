<?php
/*
 * ITHC CRM — এককালীন ইনস্টলার
 * কাজ: Master Admin অ্যাকাউন্ট তৈরি করা (পাসওয়ার্ড আপনি নিজে দেবেন)।
 * সফল হলে এই ফাইল নিজেকে মুছে ফেলে। না মুছলে নিজে File Manager থেকে মুছে দিন।
 */
require __DIR__ . '/config.php';
header('Content-Type: text/html; charset=utf-8');
header('X-Robots-Tag: noindex');

function page($title, $body) {
    echo '<!DOCTYPE html><html lang="bn"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
        . '<title>' . htmlspecialchars($title) . '</title>'
        . '<style>body{font-family:system-ui,sans-serif;background:#f1f5f9;margin:0;padding:24px}'
        . '.c{max-width:440px;margin:40px auto;background:#fff;border:1px solid #e2e8f0;border-radius:14px;padding:28px}'
        . 'h1{font-size:20px;margin:0 0 14px}label{display:block;font-size:13px;font-weight:600;margin:12px 0 4px}'
        . 'input{width:100%;padding:10px;border:1px solid #cbd5e1;border-radius:8px;box-sizing:border-box;font-size:14px}'
        . 'button{margin-top:18px;width:100%;padding:12px;border:0;border-radius:8px;background:#0f766e;color:#fff;font-weight:700;font-size:14px;cursor:pointer}'
        . '.e{background:#fee2e2;color:#b91c1c;padding:10px;border-radius:8px;font-size:13px;margin-bottom:10px}'
        . '.o{background:#dcfce7;color:#166534;padding:10px;border-radius:8px;font-size:13px}</style></head><body><div class="c">'
        . $body . '</div></body></html>';
    exit;
}

if (INSTALL_KEY === 'CHANGE_ME_TO_A_LONG_RANDOM_TEXT' || strlen(INSTALL_KEY) < 20) {
    page('Install', '<h1>config.php ঠিক করুন</h1><div class="e">config.php-তে INSTALL_KEY বদলে কমপক্ষে ২০ অক্ষরের গোপন লেখা দিন।</div>');
}

try {
    $count = (int)db()->query('SELECT COUNT(*) FROM users')->fetchColumn();
} catch (Throwable $e) {
    page('Install', '<h1>ডেটাবেস সমস্যা</h1><div class="e">ডেটাবেসে সংযোগ হয়নি বা টেবিল নেই। config.php-এর তথ্য ঠিক আছে কিনা এবং schema.sql Import হয়েছে কিনা দেখুন।</div>');
}

if ($count > 0) {
    @unlink(__FILE__);
    page('Install', '<h1>ইনস্টল সম্পন্ন</h1><div class="o">ইউজার আগেই আছে। এই install.php মুছে ফেলা হয়েছে (না মুছলে File Manager থেকে মুছে দিন)।</div>');
}

$email = db()->query("SELECT setting_value FROM settings WHERE setting_key='MASTER_ADMIN_EMAIL'")->fetchColumn();
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $key = isset($_POST['key']) ? (string)$_POST['key'] : '';
    $name = trim(isset($_POST['name']) ? (string)$_POST['name'] : '');
    $pw = isset($_POST['pw']) ? (string)$_POST['pw'] : '';
    if (!hash_equals(INSTALL_KEY, $key)) {
        $err = 'Install Key ভুল।';
    } elseif ($name === '' || mb_strlen($name) > 120) {
        $err = 'নাম দিন।';
    } elseif (mb_strlen($pw) < 10) {
        $err = 'পাসওয়ার্ড কমপক্ষে ১০ অক্ষরের হতে হবে।';
    } else {
        db()->prepare("INSERT INTO users (full_name, gmail, password_hash, role, status, active, created_at) VALUES (?,?,?,'MASTER_ADMIN','APPROVED',1,NOW())")
            ->execute(array($name, strtolower($email), password_hash($pw, PASSWORD_DEFAULT)));
        $deleted = @unlink(__FILE__);
        page('Install', '<h1>সফল!</h1><div class="o">Master Admin তৈরি হয়েছে: ' . htmlspecialchars($email) . '<br>'
            . ($deleted ? 'install.php মুছে ফেলা হয়েছে।' : '<b>এখনই File Manager থেকে install.php মুছে দিন।</b>')
            . '</div><p><a href="index.html">লগইন পেজে যান →</a></p>');
    }
}

page('Install', '<h1>ITHC CRM — প্রথম সেটআপ</h1>'
    . ($err ? '<div class="e">' . htmlspecialchars($err) . '</div>' : '')
    . '<p style="font-size:13px;color:#475569">Master Admin ইমেইল: <b>' . htmlspecialchars((string)$email) . '</b></p>'
    . '<form method="post" autocomplete="off">'
    . '<label>Install Key (config.php থেকে)</label><input type="password" name="key" required>'
    . '<label>আপনার পুরো নাম</label><input type="text" name="name" required>'
    . '<label>নতুন পাসওয়ার্ড (কমপক্ষে ১০ অক্ষর)</label><input type="password" name="pw" required minlength="10">'
    . '<button type="submit">Master Admin তৈরি করুন</button></form>');
