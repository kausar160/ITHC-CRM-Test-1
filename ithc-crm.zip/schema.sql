-- ITHC CRM — MySQL schema
-- phpMyAdmin → আপনার ডেটাবেস সিলেক্ট করুন → Import → এই ফাইল আপলোড করুন
SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(120) NOT NULL,
  gmail VARCHAR(190) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('MASTER_ADMIN','ADMIN','OPERATOR') NOT NULL DEFAULT 'OPERATOR',
  status ENUM('PENDING','APPROVED','REJECTED') NOT NULL DEFAULT 'PENDING',
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_users_gmail (gmail)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS sessions (
  token_hash CHAR(64) NOT NULL PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  expires_at DATETIME NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_sessions_user (user_id),
  KEY idx_sessions_exp (expires_at),
  CONSTRAINT fk_sessions_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS rate_limits (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  bucket VARCHAR(190) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_rl_bucket (bucket, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS departments (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  UNIQUE KEY uq_dept_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS statuses (
  name VARCHAR(40) NOT NULL PRIMARY KEY,
  sort_order INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS campaigns (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  source VARCHAR(80) NOT NULL DEFAULT '',
  cost DECIMAL(12,2) NOT NULL DEFAULT 0,
  start_date DATE NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS leads (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  patient_name VARCHAR(120) NOT NULL,
  mobile VARCHAR(25) NOT NULL,
  department VARCHAR(100) NOT NULL,
  medical_problem TEXT NOT NULL,
  lead_grade CHAR(1) NOT NULL DEFAULT 'C',
  lead_status VARCHAR(40) NOT NULL DEFAULT 'NEW',
  campaign_id INT UNSIGNED NULL,
  lead_source VARCHAR(40) NOT NULL DEFAULT 'WhatsApp',
  assigned_to VARCHAR(120) NOT NULL DEFAULT '',
  communication_count INT UNSIGNED NOT NULL DEFAULT 0,
  next_followup_date DATE NULL,
  patient_note VARCHAR(500) NOT NULL DEFAULT '',
  version INT UNSIGNED NOT NULL DEFAULT 1,
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_by INT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NULL,
  KEY idx_leads_active (active, lead_grade, lead_status),
  KEY idx_leads_followup (next_followup_date),
  KEY idx_leads_mobile (mobile),
  KEY idx_leads_campaign (campaign_id),
  CONSTRAINT fk_leads_campaign FOREIGN KEY (campaign_id) REFERENCES campaigns(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS communications (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  lead_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NULL,
  user_name VARCHAR(120) NOT NULL,
  comm_type VARCHAR(20) NOT NULL,
  comm_result VARCHAR(30) NOT NULL,
  note VARCHAR(1000) NOT NULL DEFAULT '',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_comm_lead (lead_id, id),
  CONSTRAINT fk_comm_lead FOREIGN KEY (lead_id) REFERENCES leads(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS activity_logs (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  target_id VARCHAR(30) NOT NULL DEFAULT '',
  user_id INT UNSIGNED NULL,
  user_name VARCHAR(120) NOT NULL,
  action VARCHAR(40) NOT NULL,
  field_name VARCHAR(60) NOT NULL DEFAULT '',
  old_value VARCHAR(255) NOT NULL DEFAULT '',
  new_value VARCHAR(255) NOT NULL DEFAULT '',
  note VARCHAR(255) NOT NULL DEFAULT '',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_act_time (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS settings (
  setting_key VARCHAR(60) NOT NULL PRIMARY KEY,
  setting_value VARCHAR(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS role_permissions (
  role VARCHAR(20) NOT NULL,
  permission VARCHAR(40) NOT NULL,
  PRIMARY KEY (role, permission)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ===== Seed data =====
INSERT IGNORE INTO departments (name) VALUES
 ('Cardiology'),('Oncology'),('Neurology'),('Orthopedics'),('Kidney & Urology'),('Liver'),('IVF & Fertility');

INSERT IGNORE INTO statuses (name, sort_order) VALUES
 ('NEW',1),('CONTACTED',2),('FOLLOW_UP',3),('INTERESTED',4),('HOSPITAL_SUGGESTED',5),('CONVERTED',6),('NOT_INTERESTED',7),('LOST',8);

INSERT IGNORE INTO settings (setting_key, setting_value) VALUES
 ('MASTER_ADMIN_EMAIL','kausar.pro1@gmail.com'),
 ('COMPANY_NAME','Indian Treatment Help Center'),
 ('DEFAULT_LEAD_GRADE','C'),
 ('FOLLOWUP_REMINDER','1');

-- MASTER_ADMIN এর সব পারমিশন কোডে বিল্ট-ইন। এখানে শুধু ADMIN ও OPERATOR।
INSERT IGNORE INTO role_permissions (role, permission) VALUES
 ('ADMIN','lead.create'),('ADMIN','lead.read'),('ADMIN','lead.update'),('ADMIN','lead.archive'),
 ('ADMIN','comm.create'),('ADMIN','comm.read'),
 ('ADMIN','user.create'),('ADMIN','user.read'),('ADMIN','user.update'),('ADMIN','user.approve'),
 ('ADMIN','user.reject'),('ADMIN','user.activate'),('ADMIN','user.deactivate'),
 ('ADMIN','campaign.create'),('ADMIN','campaign.read'),('ADMIN','campaign.update'),
 ('ADMIN','dashboard.read'),('ADMIN','activity.read'),('ADMIN','department.read'),
 ('OPERATOR','lead.create'),('OPERATOR','lead.read'),('OPERATOR','lead.update'),
 ('OPERATOR','comm.create'),('OPERATOR','comm.read'),
 ('OPERATOR','dashboard.read'),('OPERATOR','department.read');
